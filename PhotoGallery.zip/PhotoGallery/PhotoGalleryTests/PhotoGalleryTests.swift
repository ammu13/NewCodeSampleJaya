//
//  PhotoGalleryTests.swift
//  PhotoGalleryTests
//
//  Created by Jaya on 25/05/23.
//

import XCTest
@testable import PhotoGallery

class PhotoGalleryTests: XCTestCase {

    var viewController: ViewController!

        override func setUp() {
            super.setUp()
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            viewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as? ViewController
            viewController.loadViewIfNeeded()
        }

        override func tearDown() {
            viewController = nil
            super.tearDown()
        }
    func testFetchData() {
            
            let expectation = XCTestExpectation(description: "Fetch photos")
            viewController.fetchDatas()
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                XCTAssertTrue(self.viewController.photos.count > 0, "Photos not fetched ")
                expectation.fulfill()
            }
            wait(for: [expectation], timeout: 10)
        }
    

    }
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
    }
