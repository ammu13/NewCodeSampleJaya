//
//  PGWebHandler.swift
//  PhotoGallery
//
//  Created by Jaya on 26/05/23.
//

import Foundation
import UIKit

import Foundation
import UIKit

class WebService {
    static let shared = WebService()
    
    enum ResultResponse<T> {
        case success(T), failure(Error)
        
        /// Returns the success value from the result
        ///
        /// - Returns: success value
        /// - Throws: error
        func getValue() throws -> T {
            switch self {
            case .success(let value): return value
            case .failure(let error): throw error
            }
        }
    }
    
    func fetchPhotos(completion: @escaping (ResultResponse<[Photo]>) -> Void) {
        let urlString = Helper.PGConstants.urlString.rawValue
        guard let url = URL(string: urlString) else {
            let error = NSError(domain: Helper.PGConstants.webService.rawValue, code: -1, userInfo: [NSLocalizedDescriptionKey: Helper.PGErrors.invalidUrl])
            completion(.failure(error))
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                let error = NSError(domain: Helper.PGConstants.webService.rawValue, code: -1, userInfo: [NSLocalizedDescriptionKey: Helper.PGErrors.dataDoesNotExist(Helper.PGConstants.noData.rawValue)])
                completion(.failure(error))
                return
            }
            
            do {
                let result: ResultResponse<[Photo]> = Helper.parse(data: data)
                let photos = try result.getValue()
                completion(.success(photos))
            } catch {
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
}
