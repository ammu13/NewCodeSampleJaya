//
//  PhotoGalleryViewModel.swift
//  PhotoGallery
//
//  Created by Jaya on 26/05/23.
//

import Foundation

class PhotoGalleryViewModel {
    let webService = WebService.shared
    var photos: [Photo] = []
    var currentPage = 1
    var pageSize = 30 // Updated to display 30 cells per page
    var isLoading = false
    weak var delegate: PGModelviewProtocol?
    
    init(delegate: PGModelviewProtocol) {
        self.delegate = delegate
    }
    var totalNumberOfPages: Int {
        return 166//Int(ceil(Double(photos.count) / Double(pageSize)))
    }
    
    var numberOfPhotosForCurrentPage: Int {
        let startIndex = (currentPage - 1) * pageSize
        let endIndex = min(startIndex + pageSize, photos.count)
        return endIndex - startIndex
    }
    
    func photoForCurrentPage(at index: Int) -> Photo? {
        let startIndex = (currentPage - 1) * pageSize
        let adjustedIndex = startIndex + index
        guard adjustedIndex < photos.count else {
            return nil
        }
        return photos[adjustedIndex]
    }
    
    func setCurrentPage(_ page: Int) {
        currentPage = page
    }
    
    func photo(at index: Int) -> Photo? {
        guard index < photos.count else {
            return nil
        }
        return photos[index]
    }
    
    func fetchPhotos() {
        guard !isLoading else {
            return
        }
        isLoading = true
        webService.fetchPhotos { [weak self] result in
            guard let self = self else { return }
            
            switch result {
            case .success(let fetchedPhotos):
                self.photos = fetchedPhotos
                self.isLoading = false
                self.delegate?.apiResponseReceived(nil)
            case .failure(let error):
                self.isLoading = false
                self.delegate?.apiResponseReceived(error)
            }
        }
    }
    func showFullScreenImage(atIndex index: Int, completion: @escaping (Photo) -> Void) {
        let pageOffset = index * pageSize
        let photo = photos[pageOffset]
        completion(photo)
    }
    
    func resetData() {
        photos = []
        currentPage = 1
        isLoading = false
    }
    
    func loadNextPage() {
        //currentPage += 1
        delegate?.scrollToTop()
        //fetchPhotos()
    }
}
