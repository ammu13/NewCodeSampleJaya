//
//  FullImageViewController.swift
//  PhotoGallery
//
//  Created by Jaya on 26/05/23.
//

import UIKit

class FullImageViewController: UIViewController {
    
    private let imageURL: URL
    
    private lazy var imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    init(imageURL: URL) {
        self.imageURL = imageURL
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    fileprivate func setUp() {
        view.backgroundColor = .white
        view.addSubview(imageView)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            imageView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    fileprivate func LoadingFullImage() {
        URLSession.shared.dataTask(with: imageURL) { [weak self] (data, _, error) in
            if let error = error {
                DispatchQueue.main.async {
                    self?.showAlert(title: Helper.PGConstants.alert.rawValue , message: error.localizedDescription)
                    print("Error loading image: \(error)")
                    return
                }
            }
            
            if let data = data, let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self?.imageView.image = image
                }
            }
        }.resume()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        LoadingFullImage()
    }
}
