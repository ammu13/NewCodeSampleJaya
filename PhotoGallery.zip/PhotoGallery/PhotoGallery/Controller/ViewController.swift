//
//  ViewController.swift
//  PhotoGallery
//
//  Created by Jaya on 25/05/23.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout,UIScrollViewDelegate {
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    private var selectedIndexPath: IndexPath?
    
    // var photos: PhotoResponse = PhotoResponse(photos: [])
    private lazy var viewModel: PhotoGalleryViewModel = {
        let viewModel = PhotoGalleryViewModel(delegate: self)
        return viewModel
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startLoading(with: Helper.PGConstants.loadingPh.rawValue)
        viewModel.fetchPhotos()
    }
    
    fileprivate func setUp() {
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.isPagingEnabled = true
        let nib = UINib(nibName: Helper.PGConstants.customCell.rawValue, bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: Helper.PGConstants.customCell.rawValue)
        pageControl.numberOfPages = viewModel.totalNumberOfPages
        pageControl.currentPage = 0
        pageControl.addTarget(self, action: #selector(pageControlValueChanged), for: .valueChanged)
    }
    // MARK: - UICollectionViewDataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.numberOfPhotosForCurrentPage
    }
    @objc private func pageControlValueChanged() {
        let currentPage = pageControl.currentPage + 1
        viewModel.setCurrentPage(currentPage)
        collectionView.scrollToItem(at: IndexPath(item: 0, section: 0), at: .top, animated: true)
        collectionView.reloadData()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Helper.PGConstants.customCell.rawValue, for: indexPath) as! PhotoCollectionViewCell
        cell.isSelected = indexPath == selectedIndexPath
        if let photo = viewModel.photoForCurrentPage(at: indexPath.item) {
            cell.configure(with: photo)
        }
        return cell
    }
    
    
    // MARK: - UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let itemWidth = collectionView.bounds.width / 3 - 10
        let itemHeight = itemWidth
        return CGSize(width: itemWidth, height: itemHeight)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let photo = viewModel.photoForCurrentPage(at: indexPath.item) {
            if let urlString = photo.url, let imageURL = URL(string: urlString) {
                let fullImageViewController = FullImageViewController(imageURL: imageURL)
                present(fullImageViewController, animated: true, completion: nil)
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        //            guard let photoCell = cell as? PhotoCollectionViewCell else {
        //                return
        //            }
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y + scrollView.bounds.height
        let contentHeight = scrollView.contentSize.height
        
        // Check for the user scrolled to the next page
        if offsetY > contentHeight {
            // Check for there are more pages to display
            if viewModel.currentPage < viewModel.totalNumberOfPages {
                viewModel.currentPage += 1
                DispatchQueue.main.async { [weak self] in
                    self?.pageControl.currentPage = (self?.viewModel.currentPage ?? 1) - 1
                }
                viewModel.loadNextPage()
                collectionView.reloadData()
            }
        }
    }
}
extension ViewController: PGModelviewProtocol {
    func apiResponseReceived(_ error: Error?) {
        self.stopLoading { [weak self] in
            if let error = error {
                DispatchQueue.main.async {
                    self?.showAlert(title: Helper.PGConstants.alert.rawValue, message: error.localizedDescription)
                    return
                }
            }
        }
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
    }
    func scrollToTop() {
        DispatchQueue.main.async {
            let indexPath = IndexPath(item: 0, section: 0)
            self.collectionView.scrollToItem(at: indexPath, at: .top, animated: true)
        }
    }
}
