//
//  PhotoDataModel.swift
//  PhotoGallery
//
//  Created by Jaya on 25/05/23.
//

import Foundation

//URL : https://jsonplaceholder.typicode.com/photos
// MARK: - PhotoElement

struct Photo: Codable {
    let albumID, id: Int
    let title: String?
    let url, thumbnailURL: String?
    
    enum CodingKeys: String, CodingKey {
        case albumID = "albumId"
        case id, title, url
        case thumbnailURL = "thumbnailUrl"
    }
}
struct PhotoResponse: Codable {
    let photos: [Photo]
}

