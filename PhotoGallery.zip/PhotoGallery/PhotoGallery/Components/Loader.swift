//
//  Loader.swift
//  PhotoGallery
//
//  Created by Jaya on 25/05/23.
//

import UIKit

class Loader: UIView {
    
    private weak var visualEffectView: UIVisualEffectView!
    private weak var messageLabel: UILabel!
    var isAnimating: Bool = false
    
    var message: String? {
        didSet {
            self.messageLabel.text = message
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        setup()
    }
    
    fileprivate func setup() {
        accessibilityIdentifier = "Loader"
        self.backgroundColor = self.backgroundColor?.withAlphaComponent(0.4)
        self.alpha = 0
        self.perform(#selector(startAnimation), with: self, afterDelay: 0.2)
        self.visualEffectView = self.viewWithTag(100) as? UIVisualEffectView
        self.visualEffectView.transform = CGAffineTransform(scaleX: 1.25, y: 1.25)
        self.messageLabel = self.viewWithTag(200) as? UILabel
    }
    
    @objc private func startAnimation() {
        self.isAnimating = true
        UIView.animate(withDuration: 0.3) {
            self.alpha = 1
            self.visualEffectView.alpha = 1
            self.visualEffectView.transform = .identity
            
        }
    }
    
    func stopAnimation(_ completion:(() -> Void)?) {
        self.isAnimating = false
        UIView.animate(withDuration: 0.3, animations: {
            self.alpha = 0
            self.visualEffectView.alpha = 0
            self.visualEffectView.transform = CGAffineTransform(scaleX: 1.25, y: 1.25)
        }) { (_) in
            self.removeFromSuperview()
            completion?()
        }
    }
}
