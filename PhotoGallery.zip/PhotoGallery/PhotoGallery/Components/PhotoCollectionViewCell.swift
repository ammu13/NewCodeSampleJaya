//
//  PhotoCollectionViewCell.swift
//  PhotoGallery
//
//  Created by Jaya on 26/05/23.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    override init(frame: CGRect) {
        super.init(frame: frame)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            // Initialization code
        }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        imgView.image = nil
        lblName.text = nil
    }
    
    func configure(with photo: Photo) {
        if let imageURL = URL(string: photo.url ?? "") {
            URLSession.shared.dataTask(with: imageURL) { (data, response, error) in
                if let error = error {
                    print("Error loading image:", error)
                    return
                }
                
                if let data = data, let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self.imgView.image = image
                    }
                }
            }.resume()
        }
         let id = photo.id
            var idUse:String = ""
            idUse = String(id)
        lblName.text = idUse

    }
}
